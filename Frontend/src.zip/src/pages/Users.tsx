import { useState, useEffect } from 'react';
import axios from '../apis/axios';

function Users() {
  const [students, setStudents] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [selectedRole, setSelectedRole] = useState('student');
  const [loading, setLoading] = useState(false);

    useEffect(() => {
      setLoading(true);
      if (selectedRole === 'student') {
        axios.get('/get-student/')
        .then(res => setStudents(Array.isArray(res.data) ? res.data : []))
        .catch(() => setStudents([]))
        .finally(() => setLoading(false));
      } else {
        axios.get('/get-teacher/')
          .then(res => setTeachers(Array.isArray(res.data) ? res.data : []))
          .catch(() => setTeachers([]))
          .finally(() => setLoading(false));
      }
    }, [selectedRole]);

  const handleUpdate = (user: { id?: number; name: any; email?: string }) =>
    alert(`Update ${user.name}`);
  const handleDelete = (user: { id?: number; name: any; email?: string }) =>
    alert(`Delete ${user.name}`);

  const usersToDisplay = selectedRole === 'student' ? students : teachers;

  return (
    <div
      style={{
        display: 'flex',
        height: '100vh',
        width: '100vw',
        overflowX: 'hidden',
      }}
    >
      <nav
        style={{
          flexGrow: 0.25,
          backgroundColor: '#f8f9fa',
          padding: '2rem',
          minHeight: '100vh',
          boxSizing: 'border-box',
        }}
      >
        <h5>User Roles</h5>
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '1rem',
            marginTop: '1rem',
          }}
        >
          <button
            className={`btn btn-outline-primary ${selectedRole === 'student' ? 'active' : ''}`}
            onClick={() => setSelectedRole('student')}
          >
            Students
          </button>
          <button
            className={`btn btn-outline-primary ${selectedRole === 'teacher' ? 'active' : ''}`}
            onClick={() => setSelectedRole('teacher')}
          >
            Teachers
          </button>
        </div>
      </nav>

      <main
        style={{
          flexGrow: 1,
          padding: '2rem',
          overflowY: 'auto',
          boxSizing: 'border-box',
        }}
      >
        <h2>{selectedRole === 'student' ? 'Students' : 'Teachers'}</h2>
        {loading ? (
          <p>Loading...</p>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table className="table mt-3" style={{ minWidth: '100%' }}>
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Name</th>
                  <th>Program</th>
                  <th>password</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {Array.isArray(usersToDisplay) && usersToDisplay.length ? (
                  usersToDisplay.map((user) => (
                    <tr key={user.id}>
                      <td>{user.id}</td>
                      <td>{user.name}</td>
                      <td>{user.roll_no}</td>
                      <td>{user.program}</td>
                      <td>{user.password}</td>
                      <td>
                        <button
                          className="btn btn-sm btn-warning me-2"
                          onClick={() => handleUpdate(user)}
                        >
                          Update
                        </button>
                        <button
                          className="btn btn-sm btn-danger"
                          onClick={() => handleDelete(user)}
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={3} className="text-center">
                      No users found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </main>
    </div>
  );
}

export default Users;

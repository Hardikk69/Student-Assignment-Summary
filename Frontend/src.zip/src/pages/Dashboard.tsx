import { Link } from 'react-router-dom';

function Dashboard() {
  return (
    <div className="container mt-5">
      <h2>Admin Panel</h2>
      <ul className="nav flex-column mt-4">
        <li className="nav-item"><Link className="nav-link" to="/submit">Submit Assignment</Link></li>
        <li className="nav-item"><Link className="nav-link" to="/users">Manage Users</Link></li>
        <li className="nav-item"><Link className="nav-link text-danger" to="/">Logout</Link></li>
      </ul>
    </div>
  );
}

export default Dashboard;

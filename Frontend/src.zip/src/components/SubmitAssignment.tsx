import { useEffect, useState } from 'react';
import axios from '../apis/axios';
function SubmitAssignment() {
  const [subjects, setSubjects] = useState<any[]>([]);
  const [selected, setSelected] = useState('');
  const [file, setFile] = useState<File | null>(null);

  useEffect(() => {
    axios.get('/get-subject').then(res => setSubjects(res.data));
  }, []);

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    if (!file || !selected) return;

    const formData = new FormData();
    formData.append('subject_id', selected);
    formData.append('document', file);

    await axios.post('/submit-assignment', formData);
    alert('Assignment submitted!');
    window.location.reload();
  };

  return (
    <div
      className="d-flex justify-content-center align-items-center"
      style={{ height: '100vh', width: '100vw', backgroundColor: '#f8f9fa' }}
    >
      <div
        className="p-5 border rounded shadow bg-white text-center"
        style={{ maxWidth: '500px', width: '100%' }}
      >
        <h2 className="mb-4">Student Assignment Summary</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group text-start">
            <label>Subject</label>
            <select
              className="form-control"
              onChange={(e) => setSelected(e.target.value)}
              value={selected}
            >
              <option value="">Select subject</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
          <div className="form-group mt-3 text-start">
            <label>Attach document</label>
            <input
              type="file"
              className="form-control"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            />
          </div>
          <button type="submit" className="btn btn-success w-100 mt-4">
            Submit
          </button>
        </form>
      </div>
    </div>
  );
}

export default SubmitAssignment;

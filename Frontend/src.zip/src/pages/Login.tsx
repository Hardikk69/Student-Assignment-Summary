import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import axios from '../apis/axios';

function Login() {
  const navigate = useNavigate();
  const [id, setId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e: any) => {
    e.preventDefault();
    setError('');

    if (!id || !password) {
      setError('Please fill in all fields');
      return;
    }

    try {
      const res = await axios.post('/login/', {
        id: Number(id),
        password,
      });

      const role = res.data.role;

      if (role === 'student') navigate('/student-dashboard');
      else if (role === 'teacher') navigate('/teacher-dashboard');
      else if (role === 'admin') navigate('/admin-dashboard');
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Login failed');
    }
  };

  return (
    <div
      className="d-flex justify-content-center align-items-center"
      style={{ height: '100vh', width: '100vw', backgroundColor: '#f8f9fa' }}
    >
      <div
        className="p-5 border rounded shadow bg-white text-center"
        style={{ maxWidth: '500px', width: '100%' }}
      >
        <div className="login-header">
          <div className="icon-circle">
            <i className="bi bi-person-circle text-white fs-1"></i>
          </div>
          <h2 className="login-title">Login</h2>
        </div>
        <form onSubmit={handleLogin} className="login-form">
          <div className="form-group">
            <label>ID</label>
            <input
              type="text"
              className="form-control"
              value={id}
              onChange={(e) => setId(e.target.value)}
            />
          </div>
          <div className="form-group mt-3">
            <label>Password</label>
            <input
              type="password"
              className="form-control"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          {error && <div className="text-danger mt-2">{error}</div>}
          <button className="btn btn-primary w-100 mt-4">Log in</button>
        </form>
      </div>
    </div>
  );
}

export default Login;
